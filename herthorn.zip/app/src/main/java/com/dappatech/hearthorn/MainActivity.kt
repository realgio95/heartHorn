package com.dappatech.hearthorn

import android.media.MediaPlayer
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.dappatech.hearthorn.databinding.ActivityMainBinding
class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)

        val view = binding.root
        val hornSound = MediaPlayer.create(this, R.raw.horn)

        binding.touchMyHeart.setOnClickListener {
            hornSound.start()
        }
        this.setContentView(view);
    }
}